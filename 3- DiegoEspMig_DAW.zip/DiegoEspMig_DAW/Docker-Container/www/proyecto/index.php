<!-- index.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Camisetas</title>
</head>
<body>
    <h1>Gestión de bolígrafos</h1>
    <p><a href="registrar.php">Registrar bolígrafo</a></p>

    <p><a href="listar.php">Listar bolígrafos</a></p>
</body>
</html>